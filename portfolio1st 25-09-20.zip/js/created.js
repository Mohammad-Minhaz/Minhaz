var firstName;
firstName = "Minhaz";
console.log(firstName);
var lastName;
lastName = "Khan";
console.log(lastName);